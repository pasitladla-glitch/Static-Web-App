# EV Vibration Analysis Lab Dashboard

Static web app for EV vibration / condition-monitoring education.

## Easiest deployment: GitHub Pages
1. Create a new GitHub repository.
2. Upload **all files and folders** from this package to the repository root.
3. In GitHub: Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: `main`, folder: `/ (root)`.
6. Save and open the Pages URL.

## Local use
Opening `index.html` directly works for manual CSV upload. Browsers may block automatic loading of bundled CSV files with `file://`.

To use the `Load Student Demo` button locally, run a small web server, e.g.:

```bash
python -m http.server 8000
```

Then open http://localhost:8000

## Included datasets
- data/EV_vibration_1ms_2min_student.csv
- data/EV_vibration_1ms_2min_ground_truth.csv
- data/EV_vibration_1ms_2min_full.csv

## Core features
- CSV upload
- Dataset statistics
- Time waveform
- Operating-condition timeline
- Conventional low/high/band-pass/band-stop filtering
- 1D Kalman filtering and innovation
- Ensemble averaging
- FFT peak detection
- Motor/Wheel order evidence
- Motor-vs-road evidence scoring
- Optional Ground Truth reveal
- Responsive dashboard

## Engineering note
The diagnosis is evidence-based. It must not be treated as confirmation of a physical motor failure without engineering verification.
